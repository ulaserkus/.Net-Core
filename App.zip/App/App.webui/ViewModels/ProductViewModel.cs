using System.Collections.Generic;
using App.webui.Models;

public class ProductViewModel{
    public List<Product> Products { get; set; }
}
